public interface Flippable {
    void flip();
}