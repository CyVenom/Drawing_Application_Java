interface ImageManipulation {
    void flip();
    void scale(double factor);
    void transpose();
}